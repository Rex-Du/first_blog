CREATE VIEW sys.version AS
  SELECT
    '1.5.1'   AS `sys_version`,
    version() AS `mysql_version`;
